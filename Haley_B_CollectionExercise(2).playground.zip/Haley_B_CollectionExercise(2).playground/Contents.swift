import UIKit
// This is *NOT in alphabetical order
var myArray: [String] = ["Pokemon", "cards", "pens", "jewelry"]

// This *IS in alphabetical order
var myCollection = ["cards", "jewelry" , "pokemon", "pens"]
